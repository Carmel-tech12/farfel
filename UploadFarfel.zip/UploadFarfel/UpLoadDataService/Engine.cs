﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.IO;
using System.Net;
using System.Xml;
using System.Diagnostics;
using System.Configuration;
using System.Data.SqlClient;


namespace UpLoadDataService
{
    class Engine
    {
       

        private HttpWebRequest request;
        private CookieContainer cookieContainer = new CookieContainer();

        private static string m_ConnectionString = string.Empty;
        public static string m_folderpath = string.Empty;        
        public static string m_user = string.Empty;
        public static string m_pass = string.Empty;
        public static string m_url = string.Empty;
       // by shira
     //   public static string m_nameView = string.Empty;
        XmlDocument doc = new XmlDocument();

        public Engine()
        {
            //EventLog eventLog = new EventLog();
            //eventLog.Source = "NewSource";
            //eventLog.WriteEntry("start load global parameters", EventLogEntryType.Warning, 1001);
            File.AppendAllText(@"C:\HashConnector\carmelService\log.txt", "try load parametes"+Environment.NewLine);
            LoadGlobalParameters();
            File.AppendAllText(@"C:\HashConnector\carmelService\log.txt", "after load parametes" + Environment.NewLine);
            //eventLog.Source = "NewSource";
            //eventLog.WriteEntry("finish load global parameters", EventLogEntryType.Warning, 1001);
        }



        private void LoadGlobalParameters()
        {
            /*try
            {
               // doc.Load("Config.xml");
               // doc.Load(@"C:\Program Files\UpLoadDataService\UpLoadDataService\bin\Debug\Config.xml");
                
                doc.Load(@""+ConfigurationManager.AppSettings["pathXml"]);
            }
            catch (Exception ex)
            {
                
               EventManager.WriteEventErrorMessage("can not load the doc", ex);
            }
            
            m_ConnectionString = doc.SelectSingleNode(@"Parameters/ConenctionString").InnerText+"&quot;";
            m_user = doc.SelectSingleNode(@"Parameters/Name").InnerText;
            m_pass = doc.SelectSingleNode(@"Parameters/Pass").InnerText;
            m_url = doc.SelectSingleNode(@"Parameters/Url").InnerText;
           
          //  m_nameView = doc.SelectSingleNode(@"Parameters/nameView").InnerText;
           
            m_folderpath = doc.SelectSingleNode(@"Parameters/folderpath").InnerText;
            ConnectionManager.ConnectionString = m_ConnectionString;
            ConnectionManager.Provider = doc.SelectSingleNode(@"Parameters/Provider").InnerText;*/
            //EventLog eventLog = new EventLog();
            EventLog eventLog = new EventLog();
            try
            {
                // doc.Load("Config.xml");
                // doc.Load(@"C:\Program Files\UpLoadDataService\UpLoadDataService\bin\Debug\Config.xml");
                //EventLog eventLog = new EventLog();
                //eventLog.Source = "NewSource";
                File.AppendAllText(@"C:\HashConnector\carmelService\log.txt", "try load pathXml" + Environment.NewLine);
                //eventLog.WriteEntry("before load pathXml", EventLogEntryType.Warning, 1001);
                //doc.Load(@"" + ConfigurationManager.AppSettings["pathXml"]);
                doc.Load(@"C:\HashConnector\carmelService\farfel\Config.xml");
            }
            catch (Exception ex)
            {
                //EventLog eventLog = new EventLog();
                eventLog.Source = "NewSource";
                eventLog.WriteEntry("couldnotload pathXml", EventLogEntryType.Warning, 1001);
                File.AppendAllText(@"C:\HashConnector\carmelService\log.txt", "faile load pathXml" + Environment.NewLine);
                //EventManager.WriteEventErrorMessage("can not load the doc", ex);
            }
            
            eventLog.Source = "NewSource";
            eventLog.WriteEntry("AFTER load pathXml", EventLogEntryType.Warning, 1001);
            File.AppendAllText(@"C:\HashConnector\carmelService\log.txt", "after load pathXml" + Environment.NewLine);
            eventLog.Source = "NewSource";
            eventLog.WriteEntry("before connectionString", EventLogEntryType.Warning, 1001);
            m_ConnectionString = doc.SelectSingleNode(@"Parameters/ConenctionString").InnerText + "&quot;";
            File.AppendAllText(@"C:\HashConnector\carmelService\log.txt", "after connectionstring" + Environment.NewLine);
            eventLog.Source = "NewSource";
            eventLog.WriteEntry("AFTER connectionString", EventLogEntryType.Warning, 1001);
            m_user = doc.SelectSingleNode(@"Parameters/Name").InnerText;
            m_pass = doc.SelectSingleNode(@"Parameters/Pass").InnerText;
            eventLog.Source = "NewSource";
            eventLog.WriteEntry("before reading url", EventLogEntryType.Warning, 1001);
            m_url = doc.SelectSingleNode(@"Parameters/Url").InnerText;
            eventLog.Source = "NewSource";
            eventLog.WriteEntry("after reading url", EventLogEntryType.Warning, 1001);
            //  m_nameView = doc.SelectSingleNode(@"Parameters/nameView").InnerText;
            m_folderpath = doc.SelectSingleNode(@"Parameters/folderpath").InnerText;
            ConnectionManager.ConnectionString = m_ConnectionString;
            ConnectionManager.Provider = doc.SelectSingleNode(@"Parameters/Provider").InnerText;
         //   csv_file_path = ConfigurationManager.AppSettings["pathofcsvfile"].ToString();

        }

        #region  Procedures
        //public void LoadDataOfProcedurs()
        //{

        //    string command;
        //    XmlNodeList prodedursList = doc.GetElementsByTagName("procedure");  // XmlNodeList prodedursList = doc.GetElementsByTagName("Prodedurs");

        //    foreach (XmlNode pro in prodedursList)
        //    {
        //        //specificUrl contain the sequel of the url
        //        string specificUrl = pro.Attributes["myUrl"].Value;
             
        //        command = pro.InnerText;
        //        try
        //        {
                    
        //            DataSet dataSet = new DataSet();
        //            dataSet = ConnectionManager.GetDataForProcedures(command);
        //            string file = Savefile(ToCSV2(dataSet.Tables[0], ",", true), "from_Prodedure_"+command);
        //           //string file = Savefile(ToCSV2(dataSet.Tables[0], ",", true), "from_Prodedure_" + DateTime.Now.ToFileTime() + ".csv");
        //           //my test//string file = @"C:\rooti\temp\hash\Procedur_131474298261702609.csv";
        //            try
        //            {
        //               EventManager.WriteEventInfoMessage("try do login");
        //                doLogin(m_user, m_pass, m_url);

        //                //if success do login
        //                try
        //                {
        //                    EventManager.WriteEventInfoMessage("try upload file");
        //                    uploadfile(file, specificUrl);
        //                    EventManager.WriteEventInfoMessage("finish upload file");
        //                }
        //                catch (Exception ex)
        //                {
        //                    EventManager.WriteEventInfoMessage("cath upload file");
        //                }
        //                try
        //                {
        //                    EventManager.WriteEventInfoMessage("try do logout");
        //                    doLogout(m_url);
        //                }
        //                catch (Exception ex)
        //                {
        //                    EventManager.WriteEventInfoMessage("cath do loout");
        //                }


        //            }
        //            catch (Exception ex)
        //            {
        //                EventManager.WriteEventErrorMessage("catch login", ex);
        //            }
                    
                    
                    
                   


        //        }
        //        catch (Exception ex)
        //        {
        //            EventManager.WriteEventErrorMessage("Error while reading procedur from China", ex);

        //        }

        //     }
        //}


        #endregion



        #region  Queries 
        DataSet dataSet;
        public void LoadDataOfQueries()
        {
           
            string command;
            XmlNodeList QueriesList = doc.GetElementsByTagName("Query");  // XmlNodeList prodedursList = doc.GetElementsByTagName("Prodedurs");
            //EventManager.WriteEventInfoMessage("QueriesList");
            foreach (XmlNode pro in QueriesList)
            {

                command = pro.InnerText;
                //specificUrl contain the sequel of the url
                string specificUrl = pro.Attributes["myUrl"].Value;
                string nameView = pro.Attributes["myUrl"].Value;
                //EventManager.WriteEventInfoMessage("nameView");
               
               
                int x = nameView.IndexOf("/",2);
                //EventManager.WriteEventInfoMessage("x" + " " + x.ToString());
                nameView = nameView.Replace("/", " ");
                //EventManager.WriteEventInfoMessage("nameView" + " " + nameView);
                nameView=nameView.Substring(0,x);
                //EventManager.WriteEventInfoMessage("nameView" + " " + nameView);
             
                try
                {
                   
                    //DataSet dataSet = new DataSet();
                     dataSet = new DataSet();
                    dataSet = ConnectionManager.GetDataForQueries(command);
                    //string file = Savefile(ToCSV2(dataSet.Tables[0], ",", true), );
                    //by shira
                  
                    string file = Savefile(ToCSV2(dataSet.Tables[0], ",", true), nameView);
                    try
                    {
                        EventManager.WriteEventInfoMessage("try do login");
                        doLogin(m_user, m_pass, m_url);

                        //if success do login
                        try
                        {
                            //EventManager.WriteEventInfoMessage("try upload file");
                            uploadfile(file, specificUrl);
                            //EventManager.WriteEventInfoMessage("finish upload file");
                        }
                        catch (Exception ex)
                        {
                            EventManager.WriteEventInfoMessage("cath upload file");
                        }
                        try
                        {
                            EventManager.WriteEventInfoMessage("try do logout");
                            doLogout(m_url);
                        }
                        catch (Exception ex)
                        {
                            EventManager.WriteEventInfoMessage("cath do loout");
                        }
                    }
                    catch (Exception ex)
                    {
                        EventManager.WriteEventErrorMessage("catch login", ex);
                    }


                }
                catch (Exception ex)
                {
                    EventManager.WriteEventErrorMessage("Error while reading Query from China", ex);

                }

            }
            //עדכון סטטוס לשליחה= 2
            //UpdateCA_RequestDetails_temp();
           // UpdateCA_RequestLineDetails_temp();
        }


        #endregion
        //public void UpdateCA_RequestDetails_temp()
        //{
        //    //https://stackoverflow.com/questions/15246182/sql-update-statement-in-c-sharp
        //    using (SqlConnection connection = new SqlConnection(m_ConnectionString))
        //    {
        //        String st = "UPDATE CA_RequestDetails_temp SET StatusFlag = " + 2 +
        //             "WHERE StatusFlag = " +1;

        //        SqlCommand sqlcom = new SqlCommand(st, connection);
        //        try
        //        {
        //            connection.Open();
        //            sqlcom.ExecuteNonQuery();
        //            EventManager.WriteEventInfoMessage("update successful");
        //        }
        //        catch (SqlException ex)
        //        {
        //            EventManager.WriteEventInfoMessage("Update CA_RequestDetails_temp failed" + ex.Message);
        //        }
        //        connection.Close();
        //    }
        //}
        //public void UpdateCA_RequestLineDetails_temp()
        //{
        //    using (SqlConnection connection = new SqlConnection(m_ConnectionString))
        //    {
        //        String st = "UPDATE CA_RequestLineDetails_temp SET StatusFlag = " + 2 +
        //             "WHERE StatusFlag = " + 1;

        //        SqlCommand sqlcom = new SqlCommand(st, connection);
        //        try
        //        {
        //            connection.Open();
        //            sqlcom.ExecuteNonQuery();
        //            EventManager.WriteEventInfoMessage("update successful");
        //        }
        //        catch (SqlException ex)
        //        {
        //            EventManager.WriteEventInfoMessage("Update CA_RequestLineDetails_temp failed" + ex.Message);
        //        }
        //        connection.Close();
        //    }
        //}
        
        public string ToCSV2(DataTable table, string delimiter, bool includeHeader)
        {
            var result = new StringBuilder();

            if (includeHeader)
            {
                foreach (DataColumn column in table.Columns)
                {
                    result.Append(column.ColumnName);
                    result.Append(delimiter);
                }

                result.Remove(--result.Length, 0);
                result.Append(Environment.NewLine);
            }

            foreach (DataRow row in table.Rows)
            {
                foreach (object item in row.ItemArray)
                {
                    if (item is DBNull)
                        result.Append(delimiter);
                    else
                    {
                        string itemAsString = item.ToString();
                        // Double up all embedded double quotes
                        itemAsString = itemAsString.Replace("\"", "\"\"");

                        // To keep things simple, always delimit with double-quotes
                        // so we don't have to determine in which cases they're necessary
                        // and which cases they're not.
                        itemAsString = "\"" + itemAsString + "\"";

                        result.Append(itemAsString + delimiter);
                    }
                }

                result.Remove(--result.Length, 0);
                result.Append(Environment.NewLine);
            }

            return result.ToString();
        }

        private string Savefile(string text,string nameFile)
        {
            bool folderExists = Directory.Exists(m_folderpath);
            if (!folderExists)
                Directory.CreateDirectory(m_folderpath);

          //  string fileName = Path.Combine(m_folderpath, nameFile + "_" + DateTime.Now.ToString().Replace("/", "-").Replace(":", "-") + ".csv");
            string fileName = Path.Combine(m_folderpath, nameFile + ".csv");
            File.Create(fileName).Dispose();
            using (TextWriter tw = new StreamWriter(fileName, true, Encoding.GetEncoding("windows-1255")))
            {
                tw.WriteLine(text);
                tw.Close();
            }



            return fileName;



        }

        private void uploadfile(string filePath, string specificUrl)
        {
            string url = m_url + specificUrl;//@"importcustomercards/exportcustomercards/importcsv";
            Console.WriteLine(url);
            //Identificate separator
            string boundary = "---------------------------" + DateTime.Now.Ticks.ToString("x");
            //Encoding
            byte[] boundarybytes = System.Text.Encoding.ASCII.GetBytes("\r\n--" + boundary + "\r\n");

            //Creation and specification of the request
            HttpWebRequest wr = (HttpWebRequest)WebRequest.Create(url); //sVal is id for the webService
            wr.CookieContainer = cookieContainer;
            wr.ContentType = "multipart/form-data; boundary=" + boundary;
            wr.Method = "POST";
            wr.KeepAlive = true;
            wr.Credentials = System.Net.CredentialCache.DefaultCredentials;

            //string sAuthorization = "login:password";//AUTHENTIFICATION BEGIN
            //byte[] toEncodeAsBytes = System.Text.ASCIIEncoding.ASCII.GetBytes(sAuthorization);
            //string returnValue = System.Convert.ToBase64String(toEncodeAsBytes);
            //wr.Headers.Add("Authorization: Basic " + returnValue); //AUTHENTIFICATION END
            Stream rs = wr.GetRequestStream();


            string formdataTemplate = "Content-Disposition: form-data; name=\"{0}\"\r\n\r\n{1}"; //For the POST's format

            //Writting of the file
            rs.Write(boundarybytes, 0, boundarybytes.Length);
            byte[] formitembytes = System.Text.Encoding.UTF8.GetBytes(filePath);
            rs.Write(formitembytes, 0, formitembytes.Length);

            rs.Write(boundarybytes, 0, boundarybytes.Length);

            string headerTemplate = "Content-Disposition: form-data; name=\"{0}\"; filename=\"{1}\"\r\nContent-Type: {2}\r\n\r\n";
            string header = string.Format(headerTemplate, "file", "AAAAAAA.csv", wr.ContentType);
            byte[] headerbytes = System.Text.Encoding.UTF8.GetBytes(header);
            rs.Write(headerbytes, 0, headerbytes.Length);

            FileStream fileStream = new FileStream(filePath, FileMode.Open, FileAccess.Read);
            byte[] buffer = new byte[4096];
            int bytesRead = 0;
            while ((bytesRead = fileStream.Read(buffer, 0, buffer.Length)) != 0)
            {
                rs.Write(buffer, 0, bytesRead);
            }
            fileStream.Close();

            byte[] trailer = System.Text.Encoding.ASCII.GetBytes("\r\n--" + boundary + "--\r\n");
            rs.Write(trailer, 0, trailer.Length);
            rs.Close();
            rs = null;

            WebResponse wresp = null;
            try
            {
                //Get the response
                wresp = wr.GetResponse();
                Stream stream2 = wresp.GetResponseStream();
                StreamReader reader2 = new StreamReader(stream2);
                string responseData = reader2.ReadToEnd();
                EventManager.WriteEventInfoMessage("response is:\n" + responseData);

            }
            catch (Exception ex)
            {
                string s = ex.Message;
            }
            finally
            {
                if (wresp != null)
                {
                    wresp.Close();
                    wresp = null;
                }
                wr = null;
            }



            }

            public bool doLogin(string uid, string pwd, string url)
        {
            // Create a request using a URL that can receive a post. 
            request = (HttpWebRequest)HttpWebRequest.Create(url);
            request.CookieContainer = cookieContainer;
            //added by liat in case customer has proxy 25/04/2016  
            IWebProxy wp = WebRequest.DefaultWebProxy;
            wp.Credentials = CredentialCache.DefaultCredentials;
            request.Proxy = wp;
            //end Change
            // Set the Method property of the request to POST.
            request.Method = "POST";

            // Set the ContentType property of the WebRequest.
            request.ContentType = "application/x-www-form-urlencoded";

            // Create POST data and convert it to a byte array.
            string postData = "email=" + uid + "&password=" + pwd;
            byte[] byteArray = Encoding.UTF8.GetBytes(postData);

            // Set the ContentLength property of the WebRequest.
            request.ContentLength = byteArray.Length;
            request.KeepAlive = true;

            // Get the request stream.
            using (Stream dataStream = request.GetRequestStream())
            {
                dataStream.Write(byteArray, 0, byteArray.Length);
            }
            try
            {
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                response.Cookies = request.CookieContainer.GetCookies(request.RequestUri);
                response.Close();
            }
            catch (WebException we)
            {
            }
            catch (Exception we)
            {
            }
            //HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            //response.Cookies = request.CookieContainer.GetCookies(request.RequestUri);
            //response.Close();
            return true;

        }

        public void doLogout(string url)
        {
            // Create a request using a URL that can receive a post. 
            request = (HttpWebRequest)HttpWebRequest.Create(url);
            request.CookieContainer = cookieContainer;

            // Set the Method property of the request to POST.
            request.Method = "GET";

            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            response.Close();
        }








    }
}
